var app = angular.module('myapp',[]);
app.controller('CartForm', function($scope) {
   
$scope.cart = [
        
        {name:"Chilli Pickle", cost : 299, qty:0},
        {name:"Lemon Pickle", cost : 99, qty:0},
        {name:"Mango Pickle", cost : 249, qty:0},
        {name:"South Indian style Lemon Pickle", cost : 249, qty:0},
        {name:"Konkan style Mango Pickle", cost : 249, qty:0},
        {name:"Maharashtrian style Lemon Pickle", cost : 199, qty:0},
        {name:"Tomato Pickle", cost : 349, qty:0},
        {name:"Mixed Veg Pickle", cost : 299, qty:0},
        {name:"Kimchi style Cabbage Pickle", cost : 349, qty:0}

        
    ];
    $scope.addItem = function() {
        $scope.cart.items.push({ qty: '', name: '', cost: ''});
    };

    $scope.removeItem = function(index) {
        $scope.cart.items.splice(index, 1);
    };

    $scope.total = function() {
        var total = 0;
        angular.forEach($scope.cart, function(item) {
            total += item.qty * item.cost;
        });
        return total;
    };
});